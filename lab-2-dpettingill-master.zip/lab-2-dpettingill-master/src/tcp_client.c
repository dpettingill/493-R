#include "tcp_client.h"
#include "log.h"
#include <ctype.h>

#define PROPER_FORMAT 2
#define INITAL_BUFF_SIZE 1024
#define MAX_PORT_SIZE 65535
#define RESERVED_PORTS 1023
int v_flag = 0; // global flag for the verbose option

void help_message() {
    printf("Usage: tcp_client [--help] [-v] [-h HOST] [-p PORT] ACTION "
           "MESSAGE\n\nArguments:\n\tACTION   Must be uppercase, lowercase, title-case, reverse, "
           "or shuffle.\n\tMESSAGE  Message to send to the server\n\nOptions:\n\t--help\n\t-v, "
           "--verbose\n\t--host HOSTNAME, -h HOSTNAME\n\t--port PORT, -p PORT\n");
}

void usage_message() {
    fprintf(stderr,
            "Usage: tcp_client [--help] [-v] [-h HOST] [-p PORT] ACTION "
            "MESSAGE\n\nArguments:\n\tACTION   Must be uppercase, lowercase, title-case, reverse, "
            "or shuffle.\n\tMESSAGE  Message to send to the server\n\nOptions:\n\t--help\n\t-v, "
            "--verbose\n\t--host HOSTNAME, -h HOSTNAME\n\t--port PORT, -p PORT\n");
}

// prints out the values of a config
void print_config(Config mc) {
    log_debug("config\n port: %s\n host:%s\n file:%s", mc.port, mc.host, mc.file);
}

// Parses the options given to the program. It will return a Config struct with the necessary
// information filled in. argc and argv are provided by main. If an error occurs in processing the
// arguments and options (such as an invalid option), this function will print the correct message
// and then exit.
Config tcp_client_parse_arguments(int argc, char *argv[]) {
    log_set_quiet(true);
    Config my_config = {TCP_CLIENT_DEFAULT_PORT, TCP_CLIENT_DEFAULT_HOST,
                        NULL};          // config to send to server
    int opt, opt_i, port_num, size = 0; // option and option index

    static struct option
        long_options[] = // here we define our option struct to use with getopt_long()
        {{"host", required_argument, NULL, 'h'},
         {"port", required_argument, NULL, 'p'},
         {"verbose", no_argument, NULL, 'v'},
         {"help", no_argument, NULL, 'a'}, // case for help is 'a'
         {NULL, 0, NULL, 0}};

    // first let's get the options
    while ((opt = getopt_long(argc, argv, "vh:p:", long_options, &opt_i)) != -1) {
        switch (opt) {
        case 'a': // help option
            help_message();
            exit(EXIT_SUCCESS); // end if help is called
        case 'v':
            v_flag = 1; // set v_flag to true
            log_set_quiet(false);
            break;
        case 'h':
            my_config.host = optarg; // set the host to the option's argument
            break;
        case 'p':
            port_num = atoi(optarg);
            size = sizeof(optarg) / sizeof(optarg[0]);
            for (int i = 0; i < (size - 1); i++) { // exclude the null terminator
                if (!isdigit(optarg[i])) {
                    if (isalpha(optarg[i]) ||
                        ispunct(optarg[i])) { // check if it as an alphabetic char or a punctuation
                        fprintf(stderr, "Invalid port char given: %c at %d\n", optarg[i], i);
                        exit(EXIT_FAILURE); // invalid port
                    } else
                        break;
                }
            }
            if (port_num < RESERVED_PORTS || port_num > MAX_PORT_SIZE) {
                fprintf(stderr, "Out of bounds port number given: %d\n", port_num);
                exit(EXIT_FAILURE); // unsuccessful run
            } else {
                my_config.port = optarg; // set the port to the option's argument
            }
            break;
        case '?':
            usage_message();
            exit(EXIT_FAILURE);
        default:
            fprintf(stderr, "?? getopt returned character code 0%o ??\n", opt);
            usage_message();
            exit(EXIT_FAILURE);
        }
    }

    // if - flag is set then return that config and do not proceed
    // Or we should get a FILE
    if (optind == argc) {
        // then we weren't given any arguments and will print out help message
        fprintf(stderr, "\"FILE\" argument required\n\n");
        usage_message();
        exit(EXIT_FAILURE);
    } else if (optind > argc + 1) { // then we were given extra arguments. Not cool
        fprintf(stderr, "Too many arguments given\n\n");
        usage_message();
        exit(EXIT_FAILURE);
    } else {
        my_config.file = argv[optind]; // we have our file
        if (strchr(my_config.file, '-')) {
            log_debug("read from stdin");

            void *content = malloc(INITAL_BUFF_SIZE * 10);
            int read;
            FILE *fp = fopen("input10.txt", "w"); // create a file input10.txt to write to

            if (fp == 0)
                log_debug("...something went wrong opening file...\n");
            while ((read = fread(content, 1, 1, stdin))) {
                fwrite(content, read, 1, fp);
            }
            if (ferror(stdin))
                log_debug("There was an error reading from stdin");
            fclose(fp);
            free(content);

            my_config.file = "input10.txt";
        }
    }
    print_config(my_config); // print out my new configuration
    return my_config;
}

////////////////////////////////////////////////////
///////////// SOCKET RELATED FUNCTIONS /////////////
////////////////////////////////////////////////////

// Creates a TCP socket and connects it to the specified host and port. It returns the socket
// file descriptor.
int tcp_client_connect(Config config) {
    int status, sockfd;
    struct addrinfo hints;
    struct addrinfo *servinfo; // will point to the results

    memset(&hints, 0, sizeof hints); // make sure the struct is empty
    hints.ai_family = AF_UNSPEC;     // don't care IPv4 or IPv6
    hints.ai_socktype = SOCK_STREAM; // TCP stream sockets
    hints.ai_flags = AI_PASSIVE;     // fill in my IP for me

    log_debug("Attempting to connect to host: %s\n", config.host); // debug
    // get the address information and store it on servinfo
    if ((status = getaddrinfo(config.host, config.port, &hints, &servinfo)) != 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        exit(EXIT_FAILURE);
    }

    log_debug("Connected!\n");
    // use servinfo to get the sockfd
    sockfd = socket(servinfo->ai_family, servinfo->ai_socktype, servinfo->ai_protocol);
    if ((status = connect(sockfd, servinfo->ai_addr, servinfo->ai_addrlen)) != 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        exit(EXIT_FAILURE);
    }
    // free the memory used by the linked list servinfo
    freeaddrinfo(servinfo);
    return sockfd;
}

// Using the the action and message provided by the command line, format the data to follow the
// protocol and send it to the server. Return 1 (EXIT_FAILURE) if an error occurs, otherwise
// return 0 (EXIT_SUCCESS).
int tcp_client_send_request(int sockfd, char *action, char *message) {
    int msg_len_1, msg_len_2, bytes_sent;
    msg_len_1 = strlen(message);
    // printf("message is %d long\n", msg_len_1); // debug
    // how do I find the total length of the message I am sending? I should probs send it all at
    // once..int tot_len = action msg_len message
    char msg[msg_len_1 + 100]; // will hold total message to be sent to server
    sprintf(msg, "%s %d %s", action, msg_len_1,
            message);                                 // add a \n if you are debugging over netcat
    log_debug("our message to server is: %s\n", msg); // debug

    msg_len_2 = strlen(msg);
    if ((bytes_sent = send(sockfd, msg, msg_len_2, 0)) == -1) { // sends our stuff
        fprintf(stderr, "send error: %s\n", gai_strerror(bytes_sent));
        exit(EXIT_FAILURE);
    }

    log_debug("Bytes sent: %d\n", bytes_sent); // debug
    return bytes_sent;
}

// Receive the response from the server. The caller must provide a function pointer that handles
// the response and returns a true value if all responses have been handled, otherwise it
// returns a false value. After the response is handled by the handle_response function pointer,
// the response data can be safely deleted. The string passed to the function pointer must be
// null terminated. Return 1 (EXIT_FAILURE) if an error occurs, otherwise return 0
// (EXIT_SUCCESS).
int tcp_client_receive_response(int sockfd, int (*handle_response)(char *)) {
    u_int buf_size = INITAL_BUFF_SIZE * sizeof(char);
    char *buf = malloc(buf_size);
    int bytes_rec;
    u_int buf_index = 0; //
    int stop = 0;
    u_int msg_len = 0;
    while (1) {
        while (buf_index >= buf_size * .8) { // if we are within 20 percent of running out of room
            char *a = realloc(buf, buf_size * 2); // reallocate 2ce as much space in our buf
            if (a != NULL) {
                buf = a;       // set buf to the pointer to our new mem
                buf_size *= 2; // buf is 2ce the size now
            }
        }
        // receive call
        bytes_rec = recv(sockfd, &buf[buf_index], (buf_size - buf_index),
                         0);   // grabs buf size of bytes //** double check this number!! **//
        if (bytes_rec == -1) { // err stuff
            fprintf(stderr, "receive error: %s\n", gai_strerror(bytes_rec));
            exit(EXIT_FAILURE); // exit failure
        } else if (bytes_rec == 0) {
            log_debug("so we didn't get anything back...\n");
        }
        buf_index += bytes_rec;                 // we lost that much space in our buf
        buf[(buf_index + 1)] = '\0';            // after every recv put a '\0' at end
        log_debug("our buff contents %s", buf); // look at what we have in our b

        // handling the message stuff
        char *p = strchr(buf, ' '); // start of message
        while (*p == ' ') { // while we keep finding spaces at start of buf then look for a message
            msg_len = atoi(buf);                 // read ints from beg of buf
            log_debug("msg len: %u\n", msg_len); // debug statement
            if (buf_index >= msg_len && (msg_len != 0)) {
                char *c = malloc((msg_len + 1) * sizeof(char)); // memcpy or strncpy
                strncpy(c, (p + 1), msg_len);
                c[msg_len] = '\0'; // add null terminator to end of message
                // function pointer
                stop = (*handle_response)(c); // call response handler w/buf.
                if (stop) {                   // if we recv'ed all our msgs back then break out
                    free(buf);
                    return 0;
                }
                int index = p + 1 + msg_len - buf;
                memmove(buf, (p + 1 + msg_len), buf_index - index);
                log_debug("New buf is: %s", buf);
                buf_index = buf_index - index; // location of the end of valid stuff
                log_debug("new buf_index is: %d", buf_index);
                p = strchr(buf, ' '); // find the next space if there is one
                free(c);
            } else
                break;
        }
    }
    return 0;
}

// Close the socket when your program is done running.
void tcp_client_close(int sockfd) {
    close(sockfd);
    log_debug("Closing socket: %d\n", sockfd); // debug
}

////////////////////////////////////////////////////
////////////// FILE RELATED FUNCTIONS //////////////
////////////////////////////////////////////////////
// Given a file name, open that file for reading, returning the file object.
FILE *tcp_client_open_file(char *file_name) {
    FILE *pFile;
    pFile = fopen(file_name, "r");
    return pFile;
}

// prints an error message
// then the general help message
// exits as a failure
void print_unknown_error() {
    fprintf(stderr, "Uknown action given\n");
    usage_message();
    exit(EXIT_FAILURE);
}

// Gets the next line of a file, filling in action and message. This function should be similar
// design to getline() (https://linux.die.net/man/3/getline). *action and message must be
// allocated by the function and freed by the caller.* When this function is called, action must
// point to the action string and the message must point to the message string.
//**action and **message are pointers to char arrays aka pointers to strings.

// I am getting an extra line that I need to handle
int tcp_client_get_line(FILE *fd, char **action, char **message) {
    char *line = NULL;
    size_t len = 0;
    ssize_t read;
    const int STORE_LEN = 20;

    if (fd == NULL)
        exit(EXIT_FAILURE);

    read = getline(&line, &len, fd); // grab a line
    if (read != -1) {                // make sure I got a line
        log_debug("Retrieved line of length: %zu", read);
        log_debug("%s", line);
        *action = malloc(STORE_LEN);
        *message = malloc(sizeof(char *) * (len + 1));
        sscanf(line, "%s %[^\n]", *action, *message);
        // see if action is valid
        if (!((strcmp(*action, "uppercase") == 0) || (strcmp(*action, "lowercase") == 0) ||
              (strcmp(*action, "title-case") == 0) || (strcmp(*action, "reverse") == 0) ||
              (strcmp(*action, "shuffle") == 0)))
            print_unknown_error();
        log_debug("action: %s", *action); // check to make sure we got a valid action
        log_debug("message: %s", *message);
        free(line);
        log_debug("we just successfully got a line");
    } else {
        log_debug("Done getting lines\n");
        return 0; // we failed to get a line
    }
    return 1;
}

// Close the file when your program is done with the file.
void tcp_client_close_file(FILE *fd) { fclose(fd); }
