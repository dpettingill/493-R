#include <signal.h>
#include <stdbool.h>
#include <stdio.h>

#include "http_server.h"
#include "log.h"
static volatile int ctr_c = 0;
static volatile int sockfd;

void intHandler(int dummy) { // in the example it has a dummy int as a param. Need that?
    log_info("HANDLING INTERRUPT");
    (void)(dummy);               // tell compiler we are using dummy w/o using it
    ctr_c = 1;                   // set ctr_c flag high
    http_server_cleanup(sockfd); // close socket here as well
}

int main(int argc, char *argv[]) {
    int new_fd;
    Config main_config = http_server_parse_arguments(argc, argv);
    sockfd = http_server_create(main_config);
    signal(SIGINT, intHandler);
    while (!ctr_c) {
        new_fd = http_server_accept(sockfd); // accepts a client and creates a socket
        Request request = http_server_receive_request(new_fd); // receives a request from the client
        Response response = http_server_process_request(request, main_config.relative_path);
        http_server_send_response(new_fd, response);           // send
        http_server_client_cleanup(new_fd, request, response); // client clean up
    }

    return EXIT_SUCCESS;
}