#include <stdio.h>

#include "tcp_client.h"
int num_msg;
// return 1 for successes
// 0 for failures

// function used to handle our responses
int response_handler(char *p) {
    printf("%s\n", p); // print message!
    num_msg--;         // decrease our num msgs waiting to print
    if (num_msg)       // if we still have messages return to rec funct
        return 0;
    else
        return 1; // out of messages then finished
}

int main(int argc, char *argv[]) {
    Config main_config = tcp_client_parse_arguments(argc, argv);
    FILE *pFile = tcp_client_open_file(main_config.file); // open our file
    int line_got = 1;
    int my_sockfd = 0;
    char *action = NULL;
    char *message = NULL;
    num_msg = 0;

    my_sockfd = tcp_client_connect(main_config);
    while (line_got) { // let's get the lines
        line_got = tcp_client_get_line(pFile, &action, &message);
        if (line_got) {                                          // if we read a line then do stuff
            tcp_client_send_request(my_sockfd, action, message); // try and send our stuff
            num_msg++;    // increase our message received count
            free(action); // clean up your allocations
            free(message);
        }
    }
    tcp_client_receive_response(my_sockfd, &response_handler); // pass in sock num and fp
    tcp_client_close(my_sockfd);
    tcp_client_close_file(pFile);
    return 1; // return success
}
