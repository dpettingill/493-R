#include <signal.h>
#include <stdbool.h>
#include <stdio.h>

#include "log.h"
#include "tcp_server.h"

static volatile int ctr_c = 0;
static volatile int sockfd;

void intHandler(int dummy) { // in the example it has a dummy int as a param. Need that?
    log_info("HANDLING INTERRUPT");
    ctr_c = 1;                  // set ctr_c flag high
    tcp_server_cleanup(sockfd); // close socket here as well
}

int main(int argc, char *argv[]) {
    int new_fd;
    Config main_config = tcp_server_parse_arguments(argc, argv);
    sockfd = tcp_server_create(main_config);
    signal(SIGINT, intHandler);
    while (!ctr_c) {
        new_fd = tcp_server_accept(sockfd); // accepts a client and creates a socket
        Request request = tcp_server_receive_request(new_fd); // receives a request from the client
        Response response = tcp_server_process_request(request);
        if (strcmp(response.message, "-1") != 0) {
            tcp_server_send_response(new_fd, response);           // send
            tcp_server_client_cleanup(new_fd, request, response); // client clean up
        }
    }
    return EXIT_SUCCESS;
}