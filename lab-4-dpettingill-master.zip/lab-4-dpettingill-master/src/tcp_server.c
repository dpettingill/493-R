#include "tcp_server.h"
#include "log.h"
#include <ctype.h>
#include <time.h>

#define PROPER_FORMAT 2
#define MAX_ACTION_SIZE 15
#define INITAL_BUFF_SIZE 1024
#define MSG_LEN_SIZE 4
#define MAX_PORT_SIZE 65535
#define RESERVED_PORTS 1023
#define TCP_SERVER_DEFAULT_PORT "8083"
#define TCP_SERVER_BAD_SOCKET -1
#define TCP_SERVER_BACKLOG 10
#define TCP_SERVER_ERROR_MESSAGE "error"
int v_flag = 0; // global flag for the verbose option

void help_message() {
    printf("Usage: tcp_client [--help] [-v] [-p PORT]\n"
           "Options:\n\t--help\n\t-v, "
           "--verbose\n\t--port PORT, -p PORT\n");
}

// Parses the options given to the program. It will return a Config struct with the necessary
// information filled in. argc and argv are provided by main. If an error occurs in processing the
// arguments and options (such as an invalid option), this function will print the correct message
// and then exit.
Config tcp_server_parse_arguments(int argc, char *argv[]) {
    log_set_quiet(true);
    Config my_config = {TCP_SERVER_DEFAULT_PORT}; // config to send to server
    int opt, opt_i, size = 0, port_num;           // option and option index

    static struct option
        long_options[] = // here we define our option struct to use with getopt_long()
        {{"port", required_argument, NULL, 'p'},
         {"verbose", no_argument, NULL, 'v'},
         {"help", no_argument, NULL, 'a'}, // case for help is 'a'
         {NULL, 0, NULL, 0}};

    // first let's get the options
    while ((opt = getopt_long(argc, argv, "vp:", long_options, &opt_i)) != -1) {
        switch (opt) {
        case 'a': // help option
            help_message();
            exit(EXIT_SUCCESS); // end if help is called
        case 'v':
            v_flag = 1; // set v_flag to true
            log_set_quiet(false);
            break;
        case 'p':
            // debug if valid port real quick
            port_num = atoi(optarg);
            size = sizeof(optarg) / sizeof(optarg[0]);
            for (int i = 0; i < (size - 1); i++) { // exclude the null terminator
                if (!isdigit(optarg[i])) {
                    if (isalpha(optarg[i]) ||
                        ispunct(optarg[i])) { // check if it as an alphabetic char or a punctuation
                        fprintf(stderr, "Invalid port char given: %c at %d\n", optarg[i], i);
                        exit(EXIT_FAILURE); // invalid port
                    } else
                        break;
                }
            }
            if (port_num < RESERVED_PORTS || port_num > MAX_PORT_SIZE) {
                fprintf(stderr, "Out of bounds port number given: %d\n", port_num);
                exit(EXIT_FAILURE); // unsuccessful run
            } else {
                my_config.port = optarg; // set the port to the option's argument
            }
            break;
        case '?':
            fprintf(stderr, "?? getopt returned character code 0%o ??\n", opt);
            exit(EXIT_FAILURE);
        default:
            fprintf(stderr, "?? getopt returned character code 0%o ??\n", opt);
            exit(EXIT_FAILURE);
        }
    }
    log_trace("config: port:%s", my_config.port);
    return my_config;
}

////////////////////////////////////////////////////
///////////// SOCKET RELATED FUNCTIONS /////////////
////////////////////////////////////////////////////

// Create and bind to a server socket using the provided configuration. A socket file
// descriptor
// should be returned. If something fails, a -1 must be returned.
int tcp_server_create(Config config) {
    int status, sockfd;
    struct addrinfo hints, *res;

    memset(&hints, 0, sizeof hints); // make sure the struct is empty
    hints.ai_family = AF_UNSPEC;     // don't care IPv4 or IPv6
    hints.ai_socktype = SOCK_STREAM; // TCP stream sockets
    hints.ai_flags = AI_PASSIVE;     // fill in my IP for me

    if ((status = getaddrinfo(NULL, config.port, &hints, &res)) != 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        exit(1);
    }

    // make a socket:
    sockfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    log_trace("Creating socket: %d", sockfd);
    // bind it to the port we passed in to getaddrinfo():
    int optval;

    // set SO_REUSEADDR on a socket to true (1):
    optval = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof optval);

    bind(sockfd, res->ai_addr, res->ai_addrlen);

    freeaddrinfo(res); // free the linked-list
    return sockfd;
}

// // Listen on the provided server socket for incoming clients. When a client connects, return
// the
// // client socket file descriptor. This is a blocking call. If an error occurs, return a -1.
int tcp_server_accept(int socket) {
    struct sockaddr_storage their_addr;
    socklen_t addr_size;
    int new_fd;

    log_info("listening");
    listen(socket, TCP_SERVER_BACKLOG);

    addr_size = sizeof their_addr;
    new_fd = accept(socket, (struct sockaddr *)&their_addr, &addr_size);
    return new_fd;
}

// Read data from the provided client socket, parse the data, and return a Request struct.
// This
// function will allocate the necessary buffers to fill in the Request struct. The buffers
// contained in the Request struct must be freed using tcp_server_client_cleanup. If an error
// occurs, return an empty request and this function will free any allocated resources.
Request tcp_server_receive_request(int socket) {
    char *action = malloc(MAX_ACTION_SIZE);
    u_int buf_size = INITAL_BUFF_SIZE * sizeof(char);
    char *buf = malloc(buf_size + 5); //+ 5 just in case
    int bytes_rec;
    u_int buf_index = 0;
    int act = 0, len = 0; // bool for if we got an action
    u_int length = 0;
    char *p2 = NULL;
    while (1) {
        // receive call
        bytes_rec = recv(socket, &buf[buf_index], (buf_size - buf_index),
                         0);   // grabs buf size of bytes //** double check this number!! **//
        if (bytes_rec == -1) { // err stuff
            fprintf(stderr, "receive error: %s\n", gai_strerror(bytes_rec));
            exit(EXIT_FAILURE); // exit failure
        } else if (bytes_rec == 0) {
            log_debug("so we didn't get anything back...\n");
        }
        buf_index += bytes_rec;                 // we lost that much space in our buf
        buf[(buf_index + 1)] = '\0';            // after every recv put a '\0' at end
        log_debug("our buff contents %s", buf); // look at what we have in our b

        // handling the message stuff
        char *p = strchr(buf, ' ');        // start of message
        if (*p == ' ' && !act) {           // then we at least received an action
            strncpy(action, buf, p - buf); // grab p - buf stuff from buf and put it into action
            action[p - buf] = '\0';
            act = 1; // set action bool to 1 so we don't come looking for a new action
            p2 = strchr(p + 1, ' '); // find the next space to hopefully grab the length
            log_debug("action: %s", action);
        }
        if (*p2 == ' ' && !len) { // then we received enough for the length
            length = atoi(p);
            len = 1;
            log_debug("msg len: %u", length); // debug statement
        }
        // p2 - buf is just how much space the action and length took up in buf
        u_int msg_index = p2 - buf;
        if (length >
            (buf_size - msg_index)) { // then we need to receive more data and grow our buff size
            char *a = realloc(buf, length + 10); // reallocate space in buf to match length
            if (a != NULL) {
                buf = a;                 // set buf to the pointer to our new mem
                buf_size *= length + 10; // buf is 2ce the size now
            }
        } else {   // other wise we have all the info we need
            break; // break out of while loop
        }
    }

    char *message = malloc((length + 1) * sizeof(char));
    strncpy(message, (p2 + 1), length); // copy stuff after action and length into c
    message[length] = '\0';             // add null terminator to end of message
    log_debug("msg is: %s", message);

    Request my_request;
    my_request.action = action;
    my_request.message = message;
    free(buf);
    // will free action and message later!
    return my_request;
}

// Sends the provided Response struct on the provided client socket. Return 1 (EXIT_FAILURE if
// an error occurs, otherwise return 0 (EXIT_SUCCESS).
int tcp_server_send_response(int socket, Response response) {
    int length, bytes_sent_total = 0, bytes_sent;
    length = strlen(response.message);
    log_debug("length is: %d", length);
    while ((bytes_sent_total < length)) {
        bytes_sent = send(socket, response.message, length, 0); // sends our stuff
        bytes_sent_total += bytes_sent;
        log_debug("Bytes sent: %d\n", bytes_sent); // debug
        if (bytes_sent_total < 0) {
            fprintf(stderr, "send error: %s\n", gai_strerror(bytes_sent));
            exit(EXIT_FAILURE);
        }
    }
    return bytes_sent_total;
}

// Closes the provided CLIENT socket and cleans up allocated resources.
void tcp_server_client_cleanup(int socket, Request request, Response response) {
    close(socket);
    log_debug("closing CLIENT socket: %d", socket);
    log_info("Freeing all our stuff");
    free(request.action);
    free(request.message);
    free(response.message);
}

// Closes provided SERVER socket
void tcp_server_cleanup(int socket) {
    close(socket);
    log_debug("Closing SERVER socket: %d", socket); // debug
}

// ////////////////////////////////////////////////////
// //////////// PROTOCOL RELATED FUNCTIONS ////////////
// ////////////////////////////////////////////////////

// uppercases all characters in a message
void upperCase(char *message, char *new_message) {
    int i = 0;
    while (message[i] != '\0') {
        new_message[i] = toupper(message[i]);
        i++;
    }
    new_message[i] = '\0';
}

// lowercases all characters in a message
void lowerCase(char *message, char *new_message) {
    int i = 0;
    while (message[i] != '\0') {
        new_message[i] = tolower(message[i]);
        i++;
    }
    new_message[i] = '\0';
}

// -- To shuffle an array a of n elements (indices 0..n-1):
// for i from n−1 downto 1 do
//      j ← random integer such that 0 ≤ j ≤ i
//      exchange a[j] and a[i]
void shuffle(char *message, char *new_message) {
    srand(time(NULL)); // initialize random seed
    int length = strlen(message), j;
    char c;
    for (int i = length - 1; i > 0; i--) {
        j = rand() % (i + 1); // j btw 0 and i
        c = message[i];
        message[i] = message[j];
        message[j] = c;
    }
    strncpy(new_message, message, length);
    new_message[length] = '\0';
}

// title-cases the words in a message
void titleCase(char *message, char *new_message) {
    int i = 0;
    while (message[i] != '\0') {
        if ((isalpha(message[i]) && message[i - 1] == ' ') ||
            (i == 0 && isalpha(message[i]))) { // only 1st letter of a word
            new_message[i] = toupper(message[i]);
        } else {
            new_message[i] = message[i];
        }
        i++;
    }
    new_message[i] = '\0';
}

// reverses the characters of each word in a message
void reverse(char *message, char *new_message) {
    int i = 0, j = 0;
    j = strlen(message);
    while (message[i] != '\0') {
        new_message[i] = message[j - 1];
        i++;
        j--;
    }
    new_message[i + 1] = '\0';
}

// Convert a Request struct into a Response struct. This function will allocate the necessary
// // buffers to fill in the Response struct. The buffers contained in the Resposne struct must
// be
// // freeded using tcp_server_client_cleanup. If an error occurs, an empty
// // Response will be returned and this function will free any allocated resources.
Response tcp_server_process_request(Request request) {
    int length = strlen(request.message);
    log_debug("our length is: %d", length);
    char *message = malloc(length);
    int err = 0;
    if (strcmp(request.action, "uppercase") == 0) {
        upperCase(request.message, message);
    } else if (strcmp(request.action, "lowercase") == 0) {
        lowerCase(request.message, message);
    } else if (strcmp(request.action, "title-case") == 0) {
        titleCase(request.message, message);
    } else if (strcmp(request.action, "shuffle") == 0) {
        shuffle(request.message, message);
    } else if (strcmp(request.action, "reverse") == 0) {
        reverse(request.message, message);
    } else {
        fprintf(stderr, "unknown action\n");
        err = 1;
    }
    Response my_response;
    if (err)
        my_response.message = "-1";
    else {
        my_response.message = message;
        log_debug("our message to client: %s", message);
    }
    return my_response;
}
