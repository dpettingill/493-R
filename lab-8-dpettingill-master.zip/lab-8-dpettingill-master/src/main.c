#include "display.h"
#include "frozen.h"
#include "log.h"

#include "CLI.h"
#include <MQTTClient.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define UNUSED(x) (void)(x)
#define QOS 1
#define TIMEOUT 10000L

#define MQTT_KEEP_ALIVE_INTERVAL 30
#define MQTT_CLEAN_SESSION 1
#define CHAT_MESSAGE_TOPIC "+/message"
#define CHAT_STATUS_TOPIC "+/status"
#define TIME_AND_NAME 128

MQTTClient client;
char message_topic[100];
char status_topic[100];
char *name;
char *netid;
volatile MQTTClient_deliveryToken deliveredtoken;
// static volatile int subscribe_flag;

void received_input(char *data);
void print_config(Config mc);
void delivered(void *context, MQTTClient_deliveryToken dt);
int msgarrvd(void *context, char *topicName, int topicLen,
             MQTTClient_message *message);
void connlost(void *context, char *cause);
void publish_to_broker(char *topic, char *message, int retain);

int main(int argc, char *argv[]) {
  FILE *log_file;
  log_file = fopen("log.txt", "w");
  log_add_fp(log_file, LOG_TRACE);
  // Parse arguments
  Config config = chat_parse_cli(argc, argv);
  print_config(config);

  // Set up global variables like message_topic or status_topic (if needed)
  char *addr = malloc(NEEDED);
  sprintf(addr, "%s:%s", config.host, config.port);
  sprintf(status_topic, "%s/%s", config.netid,
          "status"); // publish all statuses here
  sprintf(message_topic, "%s/%s", config.netid,
          "message"); // publish all msgs here
  netid = config.netid;
  name = config.name == NULL ? netid : config.name;

  // Start display
  display_init();

  // Start MQTT

  // random client id
  char *clientId = malloc(10);
  srand(time(NULL));
  for (int i = 0; i < 5; i++) {
    clientId[i] = '0' + rand() % 36;
  }
  log_debug("our client id is: %s", clientId);

  // MQTTClient client;
  MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
  int rc;
  MQTTClient_create(&client, addr, clientId, MQTTCLIENT_PERSISTENCE_NONE, NULL);
  MQTTClient_willOptions will = MQTTClient_willOptions_initializer;
  char *offline_buf = malloc(sizeof(char) * NEEDED);
  offline_buf = json_asprintf("{name: %Q, online: %d}", name, 0);
  will.message = offline_buf;
  will.topicName = status_topic;
  will.retained = 1;
  will.qos = QOS;
  conn_opts.will = &will;
  conn_opts.keepAliveInterval = MQTT_KEEP_ALIVE_INTERVAL;
  conn_opts.cleansession = MQTT_CLEAN_SESSION;
  // subscribe
  MQTTClient_setCallbacks(client, NULL, connlost, msgarrvd, delivered);
  if ((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS) {
    fprintf(stderr, "Failed to connect, return code %d\n", rc);
    exit(EXIT_FAILURE);
  }
  log_debug("Subscribing to topics %s and %s using QoS %d", CHAT_MESSAGE_TOPIC,
            CHAT_STATUS_TOPIC, QOS);
  MQTTClient_subscribe(client, CHAT_MESSAGE_TOPIC, QOS);
  MQTTClient_subscribe(client, CHAT_STATUS_TOPIC, QOS);

  // publish online msg
  char *online_buf = malloc(sizeof(char) * NEEDED);
  online_buf = json_asprintf("{name: %Q, online: %d}", name, 1);
  log_debug("json: %s", online_buf);
  publish_to_broker(status_topic, online_buf, 1); // 1 sets retain true

  // Receive input from user forever...
  display_process_input(received_input);

  // clean everything up
  free(addr);
  free(online_buf);
  free(offline_buf);
  MQTTClient_disconnect(client, 10000);
  MQTTClient_destroy(&client);
  return EXIT_SUCCESS;
}

// helper functions

void publish_to_broker(char *topic, char *message, int retain) {
  MQTTClient_message pubmsg = MQTTClient_message_initializer;
  MQTTClient_deliveryToken token;
  pubmsg.payload = message;
  pubmsg.payloadlen = strlen(message);
  pubmsg.qos = QOS;
  pubmsg.retained = retain;
  deliveredtoken = 0;
  MQTTClient_publishMessage(client, topic, &pubmsg, &token);
  log_debug("Waiting for publication of %s\n"
            "on topic %s for client with ClientID: %s",
            message, topic, netid);
}

// callback function from gui
void received_input(char *data) {
  // You have received input from the user insterface

  // Convert input line into json
  char *msg = malloc(sizeof(data) + TIME_AND_NAME);
  msg = json_asprintf("{timestamp: %lu, name: %Q, message: %Q}",
                      (unsigned long)time(NULL), name, data);
  log_debug("json: %s", msg);

  // Publish data
  publish_to_broker(message_topic, msg, 0);
}

void print_config(Config mc) {
  log_debug("config\n address: %s:%s\n netid:%s\n name:%s\n", mc.host, mc.port,
            mc.netid, mc.name);
}

// notifies that our message has been delivered
// stores deliver token
void delivered(void *context, MQTTClient_deliveryToken dt) {
  (void)(context);
  log_debug("Message with token value %d delivery confirmed", dt);
  deliveredtoken = dt;
}

// handles when a messages arrives
int msgarrvd(void *context, char *topicName, int topicLen,
             MQTTClient_message *message) {
  (void)(context);
  (void)(topicLen);
  char *payloadptr;

  // display message
  payloadptr = message->payload;
  // parse through timestamp here

  char *token;
  token = strtok(topicName, "/");
  token = strtok(NULL, "/"); // we care abt the second token
  log_debug("token: %s", token);
  if (strcmp(token, "status") == 0) {
    ; // do nothing
  } else if (strcmp(token, "message") == 0) {
    log_debug("in here!");
    u_int32_t timestamp;
    char *name = malloc(NEEDED);
    char *message = malloc(sizeof(payloadptr));
    struct tm ts;
    char timeString[80];
    json_scanf(payloadptr, strlen(payloadptr),
               "{timestamp: %lu, name: %Q, message: %Q}", &timestamp, &name,
               &message);
    time_t my_ts = timestamp;
    ts = *localtime(&my_ts);
    strftime(timeString, sizeof(timeString), "%R %D", &ts);
    payloadptr = json_asprintf("{timestamp: %s, name: %Q, message: %Q}",
                               timeString, name, message);
    free(message);
    free(name);
  } else {
    log_debug("We had an error getting that msg...");
  }

  display_line(payloadptr);
  log_debug("Message arrived");
  log_debug("     topic: %s", topicName);
  log_debug("   message: %s", payloadptr);

  // clean up
  MQTTClient_freeMessage(&message);
  MQTTClient_free(topicName);
  return 1;
}

// function to inform us over stderr if connection was lost
void connlost(void *context, char *cause) {
  (void)(context);
  log_debug("\nConnection lost");
  log_debug("     cause: %s", cause);
}