#include "CLI.h"
static int v_flag = 0;

void help_message() {
  printf("Usage: tcp_client [--help] [-v] [-h HOST] [-p PORT] [-n NAME] NETID"
         "\n\nArguments:\n\tNETID The NetId of the "
         "User.\n\nOptions:\n\t--help\n\t-v, "
         "--verbose\n\t--host HOSTNAME, -h HOSTNAME\n\t--port PORT, -p PORT\n "
         "--name NAME, -n NAME\n");
}

void usage_message() {
  fprintf(stderr,
          "Usage: tcp_client [--help] [-v] [-h HOST] [-p PORT] [-n NAME] NETID"
          "\n\nArguments:\n\tNETID The NetId of the "
          "User.\n\nOptions:\n\t--help\n\t-v, "
          "--verbose\n\t--host HOSTNAME, -h HOSTNAME\n\t--port PORT, -p PORT\n "
          "--name NAME, -n NAME\n");
}

Config chat_parse_options(int argc, char *argv[], Config my_config) {
  int opt, opt_i = 0, port_num, size = 0; // option and option index

  static struct option long_options[] = // here we define our option struct to
                                        // use with getopt_long()
      {{"host", required_argument, NULL, 'h'},
       {"port", required_argument, NULL, 'p'},
       {"name", required_argument, NULL, 'n'},
       {"verbose", no_argument, NULL, 'v'},
       {"help", no_argument, NULL, 'a'}, // case for help is 'a'
       {NULL, 0, NULL, 0}};

  // first let's get the options
  while ((opt = getopt_long(argc, argv, "vh:p:n:", long_options, &opt_i)) !=
         -1) {
    switch (opt) {
    case 'a':
      help_message();
      exit(EXIT_SUCCESS); // end if help is called
    case 'v':
      v_flag = 1;
      break;
    case 'h':
      my_config.host = optarg; // set the host to the option's argument
      break;
    case 'p':
      port_num = atoi(optarg);
      size = sizeof(optarg) / sizeof(optarg[0]);
      for (int i = 0; i < (size - 1); i++) { // exclude the null terminator
        if (!isdigit(optarg[i])) {
          if (isalpha(optarg[i]) || ispunct(optarg[i])) {
            fprintf(stderr, "Invalid port char given: %c at %d\n", optarg[i],
                    i);
            exit(EXIT_FAILURE); // invalid port
          } else
            break;
        }
      }
      if (port_num < RESERVED_PORTS || port_num > MAX_PORT_SIZE) {
        fprintf(stderr, "Out of bounds port number given: %d\n", port_num);
        exit(EXIT_FAILURE); // unsuccessful run
      } else {
        my_config.port = optarg; // set the port to the option's argument
      }
      break;
    case 'n':
      my_config.name = optarg;
      break;
    case '?':
      usage_message();
      exit(EXIT_FAILURE);
    default:
      fprintf(stderr, "?? getopt returned character code 0%o ??", opt);
      usage_message();
      exit(EXIT_FAILURE);
    }
  }
  return my_config;
}

// parse the options and their arguments
// parse looking for netid action message
Config chat_parse_cli(int argc, char *argv[]) {
  log_set_quiet(true);
  Config my_config = {MQTT_CLIENT_DEFAULT_PORT, MQTT_CLIENT_DEFAULT_HOST, NULL,
                      NULL}; // config to send to server

  // parse through the options and their arguments
  my_config = chat_parse_options(argc, argv, my_config);
  // now parse through netid action message
  int args_left = argc - optind; // how many args we have left
  if (args_left != NUM_ARGS) {   // checks if we have the right num args left
    if (v_flag)
      log_set_quiet(false);
    log_debug("incorrect number of argumetns: %d", args_left);
    usage_message();
    exit(EXIT_FAILURE);
  }
  // netid
  my_config.netid = argv[argc - args_left];
  log_debug("%s", my_config.netid);
  args_left--;
  return my_config;
}