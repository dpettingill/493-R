#include "log.h"

#include "http_server.h"
#include <time.h>

// USE cURL from here on out to simulate http requests
// the 405 method not found and stuff like that are things that I
// send back to the client to let them know they did something wrong.
// not errors that I print to stderr!

#define PROPER_FORMAT 2
#define MAX_ACTION_SIZE 15
#define INITAL_BUFF_SIZE 1024
#define MSG_LEN_SIZE 4
#define MAX_PORT_SIZE 65535
#define RESERVED_PORTS 1023
#define TCP_SERVER_BAD_SOCKET -1
#define TCP_SERVER_BACKLOG 10
#define MAX_METHOD 10
#define TCP_SERVER_ERROR_MESSAGE "error"
#define PATH_MAX 4096
#define NAME_MAX 255
#define RESPONSE_SIZE 1000
#define MAX_ITS 50 // set to larger number later on
#define GET "GET"
#define METHOD_NOT_ALLOWED "405 Method Not Allowed"
#define NOT_FOUND "404 Not Found"
#define CLIENT_ERROR "400 Client Error"
#define OK "200 OK"
#define STATUS_SIZE 100

void help_message() {
    printf("Usage: tcp_client [--help] [-v] [-p PORT]\n"
           "Options:\n\t--help\n\t-v, "
           "--verbose\n\t--port PORT, -p PORT\n"
           "\t--folder FOLDER, -f FOLDER\n");
}

// Parses the options given to the program. It will return a Config struct with the necessary
// information filled in. argc and argv are provided by main. If an error occurs in processing the
// arguments and options (such as an invalid option), this function will print the correct message
// and then exit.
Config http_server_parse_arguments(int argc, char *argv[]) {
    log_set_quiet(true);
    Config my_config = {HTTP_SERVER_DEFAULT_PORT, HTTP_SERVER_DEFAULT_RELATIVE_PATH};
    int opt, opt_i, size = 0, port_num; // option and option index

    static struct option
        long_options[] = // here we define our option struct to use with getopt_long()
        {{"port", required_argument, NULL, 'p'},
         {"verbose", no_argument, NULL, 'v'},
         {"folder", required_argument, NULL, 'f'},
         {"help", no_argument, NULL, 'a'}, // case for help is 'a'
         {NULL, 0, NULL, 0}};

    // first let's get the options
    while ((opt = getopt_long(argc, argv, "vf:p:", long_options, &opt_i)) != -1) {
        switch (opt) {
        case 'a': // help option
            help_message();
            exit(EXIT_SUCCESS); // end if help is called
        case 'v':
            log_set_quiet(false);
            break;
        case 'p':
            // debug if valid port real quick
            port_num = atoi(optarg);
            size = sizeof(optarg) / sizeof(optarg[0]);
            for (int i = 0; i < (size - 1); i++) { // exclude the null terminator
                if (!isdigit(optarg[i])) {
                    if (isalpha(optarg[i]) ||
                        ispunct(optarg[i])) { // check if it as an alphabetic char or a punctuation
                        fprintf(stderr, "Invalid port char given: %c at %d\n", optarg[i], i);
                        exit(EXIT_FAILURE); // invalid port
                    } else
                        break;
                }
            }
            if (port_num < RESERVED_PORTS || port_num > MAX_PORT_SIZE) {
                fprintf(stderr, "Out of bounds port number given: %d\n", port_num);
                exit(EXIT_FAILURE); // unsuccessful run
            } else {
                my_config.port = optarg; // set the port to the option's argument
            }
            break;
        case 'f': // folder
            my_config.relative_path = optarg;
            break;
        case '?':
            fprintf(stderr, "?? getopt returned character code 0%o ??\n", opt);
            exit(EXIT_FAILURE);
        default:
            fprintf(stderr, "?? getopt returned character code 0%o ??\n", opt);
            exit(EXIT_FAILURE);
        }
    }
    log_trace("config: port: %s, relative path: %s", my_config.port, my_config.relative_path);
    return my_config;
}

////////////////////////////////////////////////////
///////////// SOCKET RELATED FUNCTIONS /////////////
////////////////////////////////////////////////////

// Create and bind to a server socket using the provided configuration. A socket file descriptor
// should be returned. If something fails, a -1 must be returned.
int http_server_create(Config config) {
    int status, sockfd, yes = 1;
    struct addrinfo hints, *res, *p;

    memset(&hints, 0, sizeof hints); // make sure the struct is empty
    hints.ai_family = AF_UNSPEC;     // don't care IPv4 or IPv6
    hints.ai_socktype = SOCK_STREAM; // TCP stream sockets
    hints.ai_flags = AI_PASSIVE;     // fill in my IP for me

    if ((status = getaddrinfo(NULL, config.port, &hints, &res)) != 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        exit(1);
    }

    // make a socket:
    for (p = res; p != NULL; p = p->ai_next) {
        if ((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
            fprintf(stderr, "problem finding a socket\n");
            continue;
        }

        if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
            fprintf(stderr, "problem finding a socket\n");
            continue;
        }

        // bind it to the port we passed in to getaddrinfo():
        if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
            close(sockfd);
            fprintf(stderr, "problem finding a socket\n");
            continue;
        }
        break;
    }

    freeaddrinfo(res); // free the linked-list
    if (p == NULL) {
        fprintf(stderr, "server: failed to bind\n");
        exit(EXIT_FAILURE);
    }
    return sockfd;
}

// Listen on the provided server socket for incoming clients. When a client connects, return the
// client socket file descriptor. This is a blocking call. If an error occurs, return a -1.
int http_server_accept(int socket) {
    struct sockaddr_storage their_addr;
    socklen_t addr_size;
    int new_fd;

    log_info("listening");
    if (listen(socket, TCP_SERVER_BACKLOG)) {
        fprintf(stderr, "listening error\n");
        exit(EXIT_FAILURE);
    }

    addr_size = sizeof their_addr;
    new_fd = accept(socket, (struct sockaddr *)&their_addr, &addr_size);
    if (new_fd == -1) {
        fprintf(stderr, "accept error\n");
        exit(EXIT_FAILURE);
    }
    log_debug("accepted. New socket: %d", new_fd);
    return new_fd;
}

// Read data from the provided client socket, parse the data, and return a Request struct. This
// function will allocate the necessary buffers to fill in the Request struct. The buffers contained
// in the Request struct must be freed using http_server_client_cleanup. If an
// error occurs, return an empty request and this function will free any allocated resources.
Request http_server_receive_request(int socket) {
    u_int buf_size = INITAL_BUFF_SIZE * sizeof(char);
    char *buf = malloc(buf_size + 5); //+ 5 just in case
    int bytes_rec;
    u_int buf_index = 0;
    char *str1 = malloc(15); // will use to check for \r\n\r\n
    int timeout = 0;
    while (1) { // go until you find the crlf at end of headers
        // timeout so we don't get stuck
        if (timeout > 5) { // 5 its of not getting anything back
            fprintf(stderr, "timeout...\n");
            exit(EXIT_FAILURE);
        } else if ((str1 != NULL) && (buf_index > 3)) { // only check this if buf is 4 or larger
            log_debug("str: %s", str1);
            if (strcmp(str1, "\r\n\r\n") == 0) {
                log_trace("we found our return/newline stuff");
                break;
            }
        }

        // receive call
        bytes_rec = recv(socket, &buf[buf_index], (buf_size - buf_index),
                         0); // grabs buf size of bytes //** double check this number!! **//
        log_debug("bytes received: %d", bytes_rec);
        if (bytes_rec == -1) { // err stuff
            fprintf(stderr, "receive error: %s\n", gai_strerror(bytes_rec));
            timeout++;
        } else if (bytes_rec == 0) {
            log_debug("so we didn't get anything back...\n");
            timeout++;
        }
        buf_index += bytes_rec; // we lost that much space in our buf
        buf[buf_index] = '\0';  // set null terminator
        log_debug("buf contents: %s", buf);
        if (buf_index > 4) {
            str1 = &buf[buf_index - 4]; // set p to the 8th thing from the end
            str1[4] = '\0';
        }
    }

    // handling the message stuff
    log_trace("message received. Going to parse now");
    Request my_request = http_server_parse_request(buf);
    free(buf); // free buf
    str1 = NULL;
    free(str1);
    return my_request;
}

int send_all(char *buf, size_t size, int socket) {
    size_t bytes_sent_total = 0, bytes_sent = 0;
    while (bytes_sent_total < size) { // send response
        bytes_sent = send(socket, buf, size, 0);
        bytes_sent_total += bytes_sent;
    }
    log_debug("bytes sent: %u", bytes_sent_total);
    return bytes_sent_total;
}

// Sends the provided Response struct on the provided client socket.int
int http_server_send_response(int socket, Response response) {
    u_int bytes_sent_total = 0;
    int i = 0;
    char *fs = malloc(HTTP_SERVER_FILE_CHUNK); // we will send the file in chunks
    char *buf = malloc(RESPONSE_SIZE);         // set an arbitrary buffer
    // gets size of contents of file
    while (i <= response.num_headers) {
        if (!i) {
            sprintf(buf, "HTTP/1.1 %s\r\n", response.status);
        } else if (i == response.num_headers) { // add an extra \r\n
            sprintf(buf, "%s %s\r\n\r\n", response.headers[i - 1]->name,
                    response.headers[i - 1]->value);
        } else { // use i-1 bc we are off an index bc we used 0 for the status
            sprintf(buf, "%s %s\r\n", response.headers[i - 1]->name,
                    response.headers[i - 1]->value);
        }
        int size = strlen(buf); // get size. sprintf null terminates
        bytes_sent_total +=
            send_all(buf, size, socket); // send size bytes from buf on socket socket
        i++;
    }

    // send chunks until
    while (1) {
        size_t bytes_read = fread(fs, sizeof(*fs), HTTP_SERVER_FILE_CHUNK, response.file);
        log_debug("bytes read: %i", bytes_read);
        bytes_sent_total += send_all(fs, bytes_read, socket);
        if (bytes_read < HTTP_SERVER_FILE_CHUNK)
            break;
    }

    free(buf);
    free(fs);
    return bytes_sent_total;
}

// Closes the provided client socket and cleans up allocated resources.
void http_server_client_cleanup(int socket, Request request, Response response) {
    close(socket);
    log_debug("closing CLIENT socket: %d", socket);
    // request stuff
    free(request.method);
    free(request.path);
    for (int i = 0; i < request.num_headers; i++) {
        free(request.headers[i]->value);
        free(request.headers[i]->name);
        free(request.headers[i]);
    }
    free(request.headers);
    log_trace("freed all of the request stuff");

    for (int i = 0; i < response.num_headers; i++) {
        log_debug("num: %d", i);
        free(response.headers[i]);
    }
    free(response.headers);
    log_trace("freed all of the response stuff");
    // response stuff
}

// Closes provided server socket
void http_server_cleanup(int socket) {
    close(socket);
    log_debug("Closing SERVER socket: %d", socket); // debug
}

////////////////////////////////////////////////////
//////////// PROTOCOL RELATED FUNCTIONS ////////////
////////////////////////////////////////////////////

// A helper function to be used inside of http_server_receive_request. This should not be used
// directly in main.c.
Request http_server_parse_request(char *buf) {
    int met = 0, pat = 0, pos, size = 5; // bools and header counter
    char *str = malloc(
        HTTP_SERVER_MAX_HEADER_SIZE); // str will hold stuff as we assign them to their buffers
    Request my_request = {NULL, NULL, 0, NULL}; // method, path, num_headers, Header **headers
    my_request.headers = malloc(HTTP_SERVER_MAX_HEADER_SIZE * size); // initialize space for the
    my_request.method = malloc(MAX_METHOD);
    my_request.path = malloc(PATH_MAX);
    char *p = buf; // start of message
    int timeout = 0;
    while (1) {
        if (timeout == MAX_ITS) {
            fprintf(stderr, "timeout...\n");
            break;
        }
        // this should be a function but can't seem to get one to work...
        pos = 0; // reset pos each while loop it
        while (*p != ' ' && *p != '\r') {
            str[pos] = *p;
            pos++;
            p++;
        }
        p++; // inc p past the ' ' or '\r' for next rd.
        if (*p == '\n') {
            p++; // inc past the '\n'
            if (*p == '\r' && *(p + 1) == '\n')
                break; // break immediately here to avoid :\r\n\r\n edge case
        }
        str[pos] = '\0';
        // now that we have a section figure out what it is
        if (!met) {
            strcpy(my_request.method, str);
            met = 1;
        } else if (!pat) {
            strcpy(my_request.path, str);
            pat = 1;
        } else {
            if (str[pos - 1] == ':') {
                if (my_request.num_headers >= size - 1) {
                    size *= 2;
                    Header **h = realloc(my_request.headers, size * HTTP_SERVER_MAX_HEADER_SIZE);
                    if (h != NULL)
                        my_request.headers = h;
                }
                my_request.headers[my_request.num_headers] = malloc(HTTP_SERVER_MAX_HEADER_SIZE);
                my_request.headers[my_request.num_headers]->name = malloc(NAME_MAX);
                my_request.headers[my_request.num_headers]->value =
                    malloc(HTTP_SERVER_MAX_HEADER_SIZE - NAME_MAX);
                strcpy(my_request.headers[my_request.num_headers]->name, str); // add in name here
                                                                               // now get the value
                // this should be a function but can't seem to get one to work...
                pos = 0; // reset pos each while loop it
                while (*p != '\r') {
                    str[pos] = *p;
                    pos++;
                    p++;
                }
                str[pos] = '\0';
                strcpy(my_request.headers[my_request.num_headers]->value, str); // add in value here
                my_request.num_headers++;
                p++; // inc p past the ' ' or '\r' for next rd.
                if (*p == '\n') {
                    p++; // inc past the '\n'
                    if (*p == '\r' && *(p + 1) == '\n')
                        break; // break immediately
                }
            }
        }
        timeout++; // checks for too many iterations (inf while)
    }

    log_trace("finished parsing");
    free(str);
    return my_request;
}

void printRequest(Request request) {
    log_debug("Request:");
    log_debug("\tMethod: %s", request.method);
    log_debug("\tPath: %s", request.path);
    log_debug("\tHeaders:");
    for (int i = 0; i < request.num_headers; i++) {
        log_debug("\t\t%s %s", request.headers[i]->name, request.headers[i]->value);
    }
}

void printResponse(Response response) {
    log_debug("Response:");
    log_debug("\tStatus: %s", response.status);
    log_debug("\tPath: %s", response.file);
    log_debug("\tHeaders:");
    for (int i = 0; i < response.num_headers; i++) {
        log_debug("\t\t%s %s", response.headers[i]->name, response.headers[i]->value);
    }
}

// Convert a Request struct into a Response struct. Use relative_path to determine the path of
// the file being requested. This function will allocate the necessary buffers to fill in the
// Response struct. The buffers contained in the Resposne struct must be freeded using
// http_server_client_cleanup. If an error occurs, an empty Response will be returned and this
// function will free any allocated resources.
Response http_server_process_request(Request request, char *relative_path) {
    int size = 0;
    size_t needed = snprintf(NULL, 0, "%s%s", relative_path, request.path) + 1;
    char *full_path = malloc(needed);
    sprintf(full_path, "%s%s", relative_path, request.path);
    log_debug("full_path: %s", full_path);
    printRequest(request);

    Response my_response; // = {NULL, NULL, 0, NULL};
    my_response.num_headers = 0;
    if ((my_response.file = fopen(full_path, "r+")) ==
        NULL) { // throw error if we didn't open a file
        fprintf(stderr, "Our file didn't open...");
        my_response.status = NOT_FOUND; // set a client error
        my_response.file = fopen("www/404.html", "r");
    } else if (request.method == NULL) { // we haven't set a status yet...
        fprintf(stderr, "Uhm no status set...");
        my_response.status = CLIENT_ERROR; // set a client error haha
        my_response.file = fopen("www/400.html", "r");
    } else if (strcmp(request.method, GET)) { // if our method isn't GET then not allowed
        my_response.status = METHOD_NOT_ALLOWED;
        my_response.file = fopen("www/405.html", "r");
    } else {
        my_response.status = OK;
    }

    // now set our response headers
    my_response.headers = malloc(HTTP_SERVER_MAX_HEADER_SIZE); // malloc space for the array
    my_response.headers[my_response.num_headers] =
        malloc(HTTP_SERVER_MAX_HEADER_SIZE); // not sure why we have to do this...
    my_response.headers[my_response.num_headers]->name = malloc(NAME_MAX);
    my_response.headers[my_response.num_headers]->value =
        malloc(HTTP_SERVER_MAX_HEADER_SIZE - NAME_MAX);
    fseek(my_response.file, 0L, SEEK_END);
    size = ftell(my_response.file);
    rewind(my_response.file);
    my_response.headers[my_response.num_headers]->name = "Content-Length:";
    sprintf(my_response.headers[my_response.num_headers]->value, "%d", size);
    my_response.num_headers++;
    printResponse(my_response); // print out the response if -v enabled
    return my_response;
}