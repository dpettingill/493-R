#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>

#include "http_server.h"
#include "log.h"

#define PATH_MAX 4096
static volatile int ctr_c = 0;
static volatile int sockfd;

typedef struct PathAndSocket {
    int socket;
    char *path;
} PathAndSocket;

pthread_t *add_thread(pthread_t *threads[], int *thread_count, int *thread_size) {
    // If we don't have room, add more space in the threads array
    if (*thread_count == *thread_size) {
        *thread_size *= 2; // Double it

        *threads = realloc(*threads, sizeof(**threads) * (*thread_size));
    }

    pthread_t *new_thread = &(*threads)[*thread_count];
    (*thread_count)++;
    return new_thread;
}

void intHandler(int dummy) { // in the example it has a dummy int as a param. Need that?
    log_info("HANDLING INTERRUPT");
    (void)(dummy);               // tell compiler we are using dummy w/o using it
    ctr_c = 1;                   // set ctr_c flag high
    http_server_cleanup(sockfd); // close socket here as well
}

void *handle_client(void *arg) {
    int *sockfd = malloc(sizeof(int));
    PathAndSocket pas = *(PathAndSocket *)arg;
    *sockfd = pas.socket;
    Request request = http_server_receive_request(*sockfd); // receives a request from the
    // sleep(5);
    Response response = http_server_process_request(request, pas.path);
    http_server_send_response(*sockfd, response);           //
    http_server_client_cleanup(*sockfd, request, response); // client clean up
    free(sockfd);
    return NULL;
}

int main(int argc, char *argv[]) {
    int thread_count = 0;
    int thread_size = 5;
    int sockfd;
    pthread_t *threads = malloc(sizeof *threads * thread_size);
    Config main_config = http_server_parse_arguments(argc, argv);
    PathAndSocket pas;
    sockfd = http_server_create(main_config);
    signal(SIGINT, intHandler);
    pas.path = main_config.relative_path;
    while (!ctr_c) {
        pas.socket = http_server_accept(sockfd); // accepts a client and creates a socket
        pthread_t *new_thread = add_thread(&threads, &thread_count, &thread_size);
        if (pthread_create(new_thread, NULL, handle_client, &pas)) {
            printf("An error occurred while creating thread.\n");
            return EXIT_FAILURE;
        }
    }

    int i = 0;
    while (i < thread_count) {
        pthread_join(threads[i], NULL);
        i++;
    }
    free(threads);
    return EXIT_SUCCESS;
}
