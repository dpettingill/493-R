#include "log.h"
#include "my_mqtt_client.h"
#include <MQTTClient.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define UNUSED(x) (void)(x)
#define QOS 1
#define TIMEOUT 10000L
volatile MQTTClient_deliveryToken deliveredtoken;
static volatile int subscribe_flag;

void print_config(Config mc) {
  log_debug("config\n address: %s\n netid:%s\n action:%s\n message:%s",
            mc.address, mc.netid, mc.action, mc.message);
}

// notifies that our message has been delivered
// stores deliver token
void delivered(void *context, MQTTClient_deliveryToken dt) {
  (void)(context);
  log_debug("Message with token value %d delivery confirmed", dt);
  deliveredtoken = dt;
}

// handles when a messages arrives
int msgarrvd(void *context, char *topicName, int topicLen,
             MQTTClient_message *message) {
  (void)(context);
  (void)(topicLen);
  int i;
  char *payloadptr;
  log_debug("Message arrived");
  log_debug("     topic: %s", topicName);
  log_debug("   message: ");
  payloadptr = message->payload;
  // prints out the message should be to stdout
  for (i = 0; i < message->payloadlen; i++) {
    putchar(*payloadptr++);
  }
  putchar('\n');
  MQTTClient_freeMessage(&message);
  MQTTClient_free(topicName);
  subscribe_flag = 1; // don't exit till we've got a message back
  return 1;
}

// function to inform us over stderr if connection was lost
void connlost(void *context, char *cause) {
  (void)(context);
  log_debug("\nConnection lost");
  log_debug("     cause: %s", cause);
}

int main(int argc, char *argv[]) {
  Config main_config = mqtt_client_parse_cli(argc, argv);
  print_config(main_config);
  char *addr = malloc(NEEDED);
  sprintf(addr, "%s:%s", main_config.host, main_config.port);
  int len = strlen(main_config.netid) + SUBSCRIBE_TOPIC_LENGTH +
            1; // plus 1 for the /
  char *sub_top = malloc(sizeof(char) * len);
  len = strlen(main_config.netid) + strlen(main_config.action) +
        1; // plus 1 for the /
  char *pub_top = malloc(sizeof(char) * len);
  sprintf(sub_top, "%s/%s", main_config.netid, SUBSCRIBE_TOPIC);
  sprintf(pub_top, "%s/%s", main_config.netid, main_config.action);
  MQTTClient client;
  MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
  subscribe_flag = 0;
  int rc;
  MQTTClient_create(&client, addr, main_config.netid,
                    MQTTCLIENT_PERSISTENCE_NONE, NULL);
  conn_opts.keepAliveInterval = 20;
  conn_opts.cleansession = 0;
  // subscribe
  MQTTClient_setCallbacks(client, NULL, connlost, msgarrvd, delivered);
  if ((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS) {
    fprintf(stderr, "Failed to connect, return code %d\n", rc);
    exit(EXIT_FAILURE);
  }
  log_debug("Subscribing to topic %s\nfor client %s using QoS %d", sub_top,
            main_config.netid, QOS);
  MQTTClient_subscribe(client, sub_top, QOS);

  // publish
  MQTTClient_message pubmsg = MQTTClient_message_initializer;
  MQTTClient_deliveryToken token;
  pubmsg.payload = main_config.message;
  pubmsg.payloadlen = strlen(main_config.message);
  pubmsg.qos = QOS;
  pubmsg.retained = 0;
  deliveredtoken = 0;
  MQTTClient_publishMessage(client, pub_top, &pubmsg, &token);
  log_debug("Waiting for publication of %s\n"
            "on topic %s for client with ClientID: %s",
            main_config.message, pub_top, main_config.netid);
  while (deliveredtoken != token)
    ;

  while (!subscribe_flag)
    ;

  free(addr);
  free(pub_top);
  free(sub_top);
  MQTTClient_disconnect(client, 10000);
  MQTTClient_destroy(&client);
  return rc;
}
