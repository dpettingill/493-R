#ifndef MQTT_CLIENT_H_
#define MQTT_CLIENT_H_

#include "log.h"
#include <ctype.h>
#include <getopt.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define MQTT_CLIENT_DEFAULT_PORT "1883"
#define MQTT_CLIENT_DEFAULT_HOST "localhost"
#define NUM_ARGS 3
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1
#define RESERVED_PORTS 1023
#define MAX_PORT_SIZE 65535
#define SUBSCRIBE_TOPIC "response"
#define SUBSCRIBE_TOPIC_LENGTH 8
#define MQTT_CLIENT_DEFAULT_ADDRESS "tcp//localhost:1883"
#define NEEDED 1024

typedef struct Config {
  char *port;
  char *host;
  char *address;
  char *netid;
  char *action;
  char *message;
} Config;

Config mqtt_client_parse_options(int argc, char *argv[], Config my_config);
Config mqtt_client_parse_cli(int argc, char *argv[]);

#endif
