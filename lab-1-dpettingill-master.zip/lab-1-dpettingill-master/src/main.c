#include <stdio.h>

#include "tcp_client.h"

int main(int argc, char *argv[]) {
    Config main_config = tcp_client_parse_arguments(argc, argv);
    int main_sockfd = tcp_client_connect(main_config);
    tcp_client_send_message(main_sockfd, main_config.action, main_config.message);
    char main_buf[TCP_CLIENT_MAX_RECEIVE_SIZE] = {0};
    int buf_size = strlen(main_config.message);
    tcp_client_receive_response(main_sockfd, main_buf, buf_size);
    tcp_client_close(main_sockfd);
    return 0;
}
