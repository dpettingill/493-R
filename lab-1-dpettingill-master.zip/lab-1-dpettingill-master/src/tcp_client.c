#include "tcp_client.h"
#include "log.h"
#include <ctype.h>

#define PROPER_FORMAT 2
#define RESERVED_PORTS 1023
#define MAX_PORT_SIZE 65535
int v_flag = 0; // global flag for the verbose option

void help_message() {
    printf("Usage: tcp_client [--help] [-v] [-h HOST] [-p PORT] ACTION "
           "MESSAGE\n\nArguments:\n\tACTION   Must be uppercase, lowercase, title-case, reverse, "
           "or shuffle.\n\tMESSAGE  Message to send to the server\n\nOptions:\n\t--help\n\t-v, "
           "--verbose\n\t--host HOSTNAME, -h HOSTNAME\n\t--port PORT, -p PORT\n");
}

void usage_message() {
    fprintf(stderr,
            "Usage: tcp_client [--help] [-v] [-h HOST] [-p PORT] ACTION "
            "MESSAGE\n\nArguments:\n\tACTION   Must be uppercase, lowercase, title-case, reverse, "
            "or shuffle.\n\tMESSAGE  Message to send to the server\n\nOptions:\n\t--help\n\t-v, "
            "--verbose\n\t--host HOSTNAME, -h HOSTNAME\n\t--port PORT, -p PORT\n");
}

// prints out the values of a config
void print_config(Config mc) {
    log_debug("config\n port: %s\n host:%s\n action:%s\n message:%s\n", mc.port, mc.host, mc.action,
              mc.message);
}

/* This function does several things
1. creates a config and fills it will data obtained from the user
2. if incorrect data is given it outputs the appropriate syntax
3. takes in and uses options to help the user
*/
Config tcp_client_parse_arguments(int argc, char *argv[]) {
    Config my_config = {TCP_CLIENT_DEFAULT_PORT, TCP_CLIENT_DEFAULT_HOST, NULL,
                        NULL};              // config to send to server
    int opt, opt_i = 0, port_num, size = 0; // option and option index

    static struct option
        long_options[] = // here we define our option struct to use with getopt_long()
        {{"host", required_argument, NULL, 'h'},
         {"port", required_argument, NULL, 'p'},
         {"verbose", no_argument, NULL, 'v'},
         {"help", no_argument, NULL, 'a'}, // case for help is 'a'
         {NULL, 0, NULL, 0}};

    // first let's get the options
    while ((opt = getopt_long(argc, argv, "vh:p:", long_options, &opt_i)) != -1) {
        switch (opt) {
        case 'a':
            help_message();
            exit(EXIT_SUCCESS); // end if help is called
        case 'v':
            v_flag = 1; // set v_flag to true
            break;
        case 'h':
            my_config.host = optarg; // set the host to the option's argument
            break;
        case 'p':
            port_num = atoi(optarg);
            size = sizeof(optarg) / sizeof(optarg[0]);
            for (int i = 0; i < (size - 1); i++) { // exclude the null terminator
                if (!isdigit(optarg[i])) {
                    if (isalpha(optarg[i]) || ispunct(optarg[i])) {
                        fprintf(stderr, "Invalid port char given: %c at %d\n", optarg[i], i);
                        exit(EXIT_FAILURE); // invalid port
                    } else
                        break;
                }
            }
            if (port_num < RESERVED_PORTS || port_num > MAX_PORT_SIZE) {
                fprintf(stderr, "Out of bounds port number given: %d\n", port_num);
                exit(EXIT_FAILURE); // unsuccessful run
            } else {
                my_config.port = optarg; // set the port to the option's argument
            }
            break;
        case '?':
            usage_message();
            exit(EXIT_FAILURE);
        default:
            fprintf(stderr, "?? getopt returned character code 0%o ??\n", opt);
            usage_message();
            exit(EXIT_FAILURE);
        }
    }

    // now we should get an ACTION then a MESSAGE
    int action = 0;
    if (optind == argc) { // then we weren't given any arguments and will print out help message
        fprintf(stderr, "'action' and 'message' arguments are required\n\n");
        usage_message();
        exit(EXIT_FAILURE);
    }
    for (; optind < argc; optind++) {
        if (action) {                  // if we've got an action then we're looking for a message
            if ((optind + 1) < argc) { // if there is another thing after the message then error
                fprintf(stderr, "Seems like you gave an extra argument...\n\n");
                usage_message();
                exit(EXIT_FAILURE);
            }                                 // else
            my_config.message = argv[optind]; // set message in my_config.
        } else if ((strcmp(argv[optind], "uppercase") == 0) ||
                   (strcmp(argv[optind], "lowercase") == 0) ||
                   (strcmp(argv[optind], "title-case") == 0) ||
                   (strcmp(argv[optind], "reverse") == 0) ||
                   (strcmp(argv[optind], "shuffle") ==
                    0)) { // checks to see if any of the actions are a match
            // then sets the config addr to argv[optind]
            if ((optind + 1) >= argc) { // we should have a message waiting for us
                fprintf(stderr, "Looks like you forgot a message jack\n\n");
                usage_message();
                exit(EXIT_FAILURE);
            }
            action = 1; // set action to true
            my_config.action = argv[optind];
        } else {
            usage_message(); // prints out a message of how to correctly format
            exit(EXIT_FAILURE);
            break;
        }
    }

    print_config(my_config); // print out my new configuration if v flag is set
    return my_config;
}

int tcp_client_connect(Config config) {
    int status, sockfd;
    struct addrinfo hints;
    struct addrinfo *servinfo; // will point to the results

    memset(&hints, 0, sizeof hints); // make sure the struct is empty
    hints.ai_family = AF_UNSPEC;     // don't care IPv4 or IPv6
    hints.ai_socktype = SOCK_STREAM; // TCP stream sockets
    hints.ai_flags = AI_PASSIVE;     // fill in my IP for me

    log_debug("Attempting to connect to host: %s", config.host); // debug
    // get the address information and store it on servinfo
    if ((status = getaddrinfo(config.host, config.port, &hints, &servinfo)) != 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        exit(EXIT_FAILURE);
    }

    log_debug("connected!");
    // use servinfo to get the sockfd
    sockfd = socket(servinfo->ai_family, servinfo->ai_socktype, servinfo->ai_protocol);
    if ((status = connect(sockfd, servinfo->ai_addr, servinfo->ai_addrlen)) != 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        exit(EXIT_FAILURE);
    }
    // free the memory used by the linked list servinfo
    freeaddrinfo(servinfo);
    return sockfd;
}

void tcp_client_send_message(int sockfd, char *action, char *message) {
    int msg_len_1, msg_len_2, bytes_sent;
    msg_len_1 = strlen(message);
    // printf("message is %d long\n", msg_len_1); // debug
    // how do I find the total length of the message I am sending? I should probs send it all at
    // once..int tot_len = action msg_len message
    char msg[1026]; // will hold total message to be sent to server
    sprintf(msg, "%s %d %s", action, msg_len_1, message);
    log_debug("our message to server is: %s\n", msg); // debug

    msg_len_2 = strlen(msg);
    if ((bytes_sent = send(sockfd, msg, msg_len_2, 0)) == -1) { // sends our stuff
        fprintf(stderr, "send error: %s\n", gai_strerror(bytes_sent));
        exit(EXIT_FAILURE);
    }

    log_debug("Bytes sent: %d\n", bytes_sent); // debug
}

void tcp_client_receive_response(int sockfd, char *buf, int buf_size) {
    int bytes_rec;
    bytes_rec = recv(sockfd, buf, buf_size,
                     0); // receives input from server and tracks how many bytes received
    if (bytes_rec == -1) {
        fprintf(stderr, "receive error: %s\n", gai_strerror(bytes_rec));
        exit(EXIT_FAILURE);
    } else if (bytes_rec == 0) {
        fprintf(stderr, "so we didn't get anything back...\n");
    } else {
        if (v_flag == 1) {
            fprintf(stderr, "bytes received: %d\n", bytes_rec); // debug
            fprintf(stderr, "Output from Server: ");
        }
        printf("%s\n", buf); // outputs the buffer from the server
    }
}

void tcp_client_close(int sockfd) {
    log_debug("Closing socket: %d\n", sockfd); // debug
}
